
/**
 * HERO - BACKEND SERVER
 * Stack: Node.js, Express, MongoDB, Socket.io
 */

const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: "*" }
});

app.use(cors());
app.use(express.json());

// --- MongoDB Schema Definitions ---

const UserSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  name: String,
  password: { type: String, default: 'password' },
  city: String,
  avatar: String,
  bio: String,
  joinDate: { type: Date, default: Date.now }
});

const MessageSchema = new mongoose.Schema({
  senderId: String,
  senderName: String,
  text: String,
  timestamp: { type: Date, default: Date.now }
});

const RequestSchema = new mongoose.Schema({
  name: String,
  phone: String,
  address: String,
  description: String,
  category: String,
  urgency: String,
  status: { type: String, enum: ['live', 'accepted', 'completed', 'expired'], default: 'live' },
  timestamp: { type: Date, default: Date.now },
  acceptedBy: String,
  acceptedByName: String,
  messages: [MessageSchema],
  location: {
    lat: Number,
    lng: Number
  }
});

// Note: In a real environment, you would use:
// mongoose.connect(process.env.MONGODB_URI);

// --- API Routes ---

app.get('/api/requests', async (req, res) => {
  // Logic: Fetch all requests from MongoDB
  res.json({ success: true, data: [] });
});

app.post('/api/requests', async (req, res) => {
  // Logic: Create new request and broadcast via Socket.io
  const newRequest = req.body;
  io.emit('new_request', newRequest);
  res.status(201).json({ success: true, data: newRequest });
});

app.patch('/api/requests/:id', async (req, res) => {
  // Logic: Update request status (e.g., Accept Mission)
  const { id } = req.params;
  const updates = req.body;
  io.emit('update_request', { id, ...updates });
  res.json({ success: true });
});

// --- Socket.io Real-time Logic ---

io.on('connection', (socket) => {
  console.log('User connected to Hero Network:', socket.id);

  socket.on('send_message', (data) => {
    // Logic: Save to DB and broadcast to the specific mission room
    io.emit('receive_message', data);
  });

  socket.on('disconnect', () => {
    console.log('User disconnected');
  });
});

// server.listen(3000, () => console.log('Hero Backend running on port 3000'));
