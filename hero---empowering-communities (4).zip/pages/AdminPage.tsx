
import React, { useState, useMemo } from 'react';
import { Routes, Route, Link, useNavigate, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  ClipboardList, 
  LogOut, 
  ArrowLeft, 
  Search, 
  Activity, 
  Trash2,
  Menu,
  X,
  BarChart3,
  CheckCircle2,
  AlertCircle,
  Clock,
  MoreVertical,
  ChevronRight,
  ShieldCheck,
  TrendingUp,
  PieChart,
  Zap,
  Users,
  UserX,
  ShieldAlert,
  Archive,
  MapPin,
  Trophy,
  ArrowUpRight,
  ChevronLeft
} from 'lucide-react';
import { AppState, HelpRequest, Category, Urgency, User } from '../types';
import { storageService } from '../services/storageService';
import { CATEGORIES } from '../constants';

// --- Visualization Components ---

const MissionLineChart = ({ data }: { data: number[] }) => {
  const max = Math.max(...data, 5);
  const height = 100;
  const width = 600;
  const points = data.map((d, i) => ({
    x: (i / (data.length - 1 || 1)) * width,
    y: height - (d / max) * height
  }));
  const pathD = `M ${points.map(p => `${p.x},${p.y}`).join(' L ')}`;
  const areaD = `${pathD} L ${width},${height} L 0,${height} Z`;

  return (
    <div className="w-full h-40">
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full overflow-visible" preserveAspectRatio="none">
        <defs>
          <linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#5e5ce6" stopOpacity="0.3" />
            <stop offset="100%" stopColor="#5e5ce6" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path d={areaD} fill="url(#chartGradient)" />
        <path d={pathD} fill="none" stroke="#5e5ce6" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
        {points.map((p, i) => (
          <circle key={i} cx={p.x} cy={p.y} r="4" fill="white" stroke="#5e5ce6" strokeWidth="2" />
        ))}
      </svg>
    </div>
  );
};

const DonutChart = ({ segments }: { segments: { label: string, value: number, color: string }[] }) => {
  const total = segments.reduce((acc, s) => acc + s.value, 0);
  let currentAngle = -90;
  
  return (
    <div className="relative w-32 h-32 sm:w-40 sm:h-40">
      <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
        {segments.map((s, i) => {
          if (total === 0) return null;
          const percentage = (s.value / total) * 100;
          const dashOffset = -currentAngle;
          currentAngle += (percentage / 100) * 360;
          
          return (
            <circle
              key={i}
              cx="50"
              cy="50"
              r="40"
              fill="transparent"
              stroke={s.color}
              strokeWidth="12"
              strokeDasharray="251.2" // 2 * pi * r
              strokeDashoffset={251.2 * (1 - percentage / 100)}
              style={{ transform: `rotate(${(currentAngle - (percentage / 100) * 360) + 90}deg)`, transformOrigin: '50% 50%' }}
              strokeLinecap="round"
            />
          );
        })}
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-xl sm:text-2xl font-black text-[#1a1a1a]">{total}</span>
        <span className="text-[8px] font-black text-gray-400 uppercase tracking-widest">Total</span>
      </div>
    </div>
  );
};

const CategoryBarChart = ({ data }: { data: Record<string, number> }) => {
  const max = Math.max(...Object.values(data), 1);
  return (
    <div className="space-y-4 w-full">
      {Object.entries(data).map(([cat, count]) => (
        <div key={cat} className="space-y-1.5">
          <div className="flex justify-between text-[10px] font-black uppercase tracking-widest text-gray-500">
            <span>{cat}</span>
            <span className="text-[#1a1a1a]">{count}</span>
          </div>
          <div className="w-full bg-gray-50 h-3 rounded-full overflow-hidden border border-gray-100">
            <div 
              className="h-full bg-[#5e5ce6] rounded-full transition-all duration-1000 ease-out shadow-[0_0_12px_rgba(94,92,230,0.3)]"
              style={{ width: `${(count / max) * 100}%` }}
            />
          </div>
        </div>
      ))}
    </div>
  );
};

const UrgencyComparison = ({ data }: { data: { emergency: number, urgent: number, standard: number } }) => {
  const max = Math.max(data.emergency, data.urgent, data.standard, 1);
  const items = [
    { label: 'Emergency', value: data.emergency, color: 'bg-rose-500' },
    { label: 'Urgent', value: data.urgent, color: 'bg-orange-500' },
    { label: 'Standard', value: data.standard, color: 'bg-indigo-500' }
  ];

  return (
    <div className="flex items-end justify-between gap-4 h-48 w-full pt-4 px-2">
      {items.map((item, i) => (
        <div key={i} className="flex-1 flex flex-col items-center gap-3">
          <div className="relative group w-full flex flex-col items-center">
             <div className="absolute -top-6 text-[10px] font-black text-gray-400 opacity-0 group-hover:opacity-100 transition-opacity">
                {item.value}
             </div>
             <div 
               className={`w-full max-w-[40px] ${item.color} rounded-t-xl transition-all duration-700 ease-out`}
               style={{ height: `${(item.value / max) * 140}px` }}
             />
          </div>
          <span className="text-[8px] font-black uppercase tracking-widest text-gray-400 rotate-45 sm:rotate-0 mt-4 sm:mt-0">
            {item.label}
          </span>
        </div>
      ))}
    </div>
  );
};

// --- Page Components ---

const AdminDashboard = ({ state }: { state: AppState }) => {
  const stats = useMemo(() => {
    const live = state.requests.filter(r => r.status === 'live').length;
    const accepted = state.requests.filter(r => r.status === 'accepted').length;
    const completed = state.requests.filter(r => r.status === 'completed').length;
    const expired = state.requests.filter(r => r.status === 'expired').length;
    
    // Category Breakdown
    const catCounts: Record<string, number> = {};
    Object.values(Category).forEach(c => catCounts[c] = 0);
    state.requests.forEach(r => {
      catCounts[r.category] = (catCounts[r.category] || 0) + 1;
    });

    // Urgency Breakdown
    const urgencyCounts = {
      emergency: state.requests.filter(r => r.urgency === 'EMERGENCY').length,
      urgent: state.requests.filter(r => r.urgency === 'URGENT').length,
      standard: state.requests.filter(r => r.urgency === 'STANDARD').length,
    };

    // City Stats
    const cities: Record<string, number> = {};
    state.requests.forEach(r => {
      const cityMatch = r.address.split(',').pop()?.trim();
      if (cityMatch) cities[cityMatch] = (cities[cityMatch] || 0) + 1;
    });
    const topCities = Object.entries(cities)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 3);

    const rescueRate = completed + expired > 0 
      ? Math.round((completed / (completed + expired)) * 100) 
      : 0;
    
    // Fake trend data
    const trend = [2, 5, 3, 8, 12, 7, 15, 10, 18, 22];
    
    return { live, accepted, completed, expired, trend, catCounts, urgencyCounts, topCities, rescueRate };
  }, [state.requests]);

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
        <div>
          {/* CRITICAL: Added back button to Live Request Page (Home) */}
          <Link to="/" className="flex items-center gap-2 text-[#6e6e73] hover:text-[#5e5ce6] font-black text-xs mb-4 group transition-colors">
            <ArrowLeft size={16} className="transition-transform group-hover:-translate-x-1" /> Back to Live Requests
          </Link>
          <h1 className="text-[32px] font-black text-[#1a1a1a] tracking-tight leading-none">Intelligence Hub</h1>
          <p className="text-[#6e6e73] font-medium mt-2">Global response and community impact analytics</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="bg-emerald-50 text-emerald-600 px-5 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 border border-emerald-100 shadow-sm">
            <Activity size={14} className="animate-pulse" /> System v4.2 Online
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Total Missions', value: state.requests.length, icon: <ClipboardList />, color: 'text-indigo-500', bg: 'bg-indigo-50', trend: '+12%' },
          { label: 'Active Users', value: state.users.length, icon: <Users />, color: 'text-blue-500', bg: 'bg-blue-50', trend: '+5%' },
          { label: 'Expired Tasks', value: stats.expired, icon: <Archive />, color: 'text-gray-400', bg: 'bg-gray-100', trend: '-2%' },
          { label: 'Success Rate', value: `${stats.rescueRate}%`, icon: <Trophy />, color: 'text-amber-500', bg: 'bg-amber-50', trend: 'High' },
        ].map((s, i) => (
          <div key={i} className="bg-white p-6 rounded-[32px] border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex justify-between items-start mb-4">
              <div className={`w-12 h-12 ${s.bg} ${s.color} rounded-2xl flex items-center justify-center`}>
                {React.cloneElement(s.icon as React.ReactElement, { size: 20 })}
              </div>
              <div className="text-[10px] font-black text-emerald-500 flex items-center gap-1">
                {s.trend} <ArrowUpRight size={10} />
              </div>
            </div>
            <div>
              <div className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">{s.label}</div>
              <div className="text-3xl font-black text-[#1a1a1a] tracking-tight">{s.value}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Growth Chart */}
        <div className="lg:col-span-2 bg-white p-8 rounded-[40px] border border-gray-100 shadow-sm">
          <div className="flex items-center justify-between mb-10">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center text-[#5e5ce6]">
                <TrendingUp size={20} />
              </div>
              <div>
                <h3 className="text-xs font-black text-[#1a1a1a] uppercase tracking-widest leading-none">Activity Growth</h3>
                <p className="text-[10px] text-gray-400 font-bold uppercase mt-1">Missions over time</p>
              </div>
            </div>
          </div>
          <MissionLineChart data={stats.trend} />
        </div>

        {/* Status Donut */}
        <div className="bg-white p-8 rounded-[40px] border border-gray-100 shadow-sm flex flex-col items-center justify-between text-center min-h-[400px]">
          <div className="w-full flex items-center gap-3 mb-8 text-left">
            <div className="w-10 h-10 bg-rose-50 rounded-xl flex items-center justify-center text-rose-500">
              <PieChart size={20} />
            </div>
            <div>
              <h3 className="text-xs font-black text-[#1a1a1a] uppercase tracking-widest leading-none">Status Breakdown</h3>
              <p className="text-[10px] text-gray-400 font-bold uppercase mt-1">Lifecycle distribution</p>
            </div>
          </div>
          <DonutChart segments={[
            { label: 'Live', value: stats.live, color: '#f43f5e' },
            { label: 'Accepted', value: stats.accepted, color: '#f59e0b' },
            { label: 'Completed', value: stats.completed, color: '#10b981' },
            { label: 'Expired', value: stats.expired, color: '#9ca3af' }
          ]} />
          <div className="grid grid-cols-2 gap-4 w-full mt-8">
             <div className="bg-gray-50 p-3 rounded-2xl">
               <div className="text-[9px] font-black text-emerald-500 uppercase tracking-widest">Efficiency</div>
               <div className="text-xl font-black">{stats.rescueRate}%</div>
             </div>
             <div className="bg-gray-50 p-3 rounded-2xl">
               <div className="text-[9px] font-black text-rose-500 uppercase tracking-widest">Active</div>
               <div className="text-xl font-black">{stats.live}</div>
             </div>
          </div>
        </div>

        {/* Category Bar Chart */}
        <div className="bg-white p-8 rounded-[40px] border border-gray-100 shadow-sm">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 bg-amber-50 rounded-xl flex items-center justify-center text-amber-500">
              <BarChart3 size={20} />
            </div>
            <div>
              <h3 className="text-xs font-black text-[#1a1a1a] uppercase tracking-widest leading-none">Demand by Sector</h3>
              <p className="text-[10px] text-gray-400 font-bold uppercase mt-1">Requests per category</p>
            </div>
          </div>
          <CategoryBarChart data={stats.catCounts} />
        </div>

        {/* Urgency Heatmap */}
        <div className="bg-white p-8 rounded-[40px] border border-gray-100 shadow-sm">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center text-[#5e5ce6]">
              <Zap size={20} />
            </div>
            <div>
              <h3 className="text-xs font-black text-[#1a1a1a] uppercase tracking-widest leading-none">Urgency Heatmap</h3>
              <p className="text-[10px] text-gray-400 font-bold uppercase mt-1">Mission severity spread</p>
            </div>
          </div>
          <UrgencyComparison data={stats.urgencyCounts} />
        </div>

        {/* Geographic Hotspots */}
        <div className="bg-white p-8 rounded-[40px] border border-gray-100 shadow-sm">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-emerald-50 rounded-xl flex items-center justify-center text-emerald-500">
              <MapPin size={20} />
            </div>
            <div>
              <h3 className="text-xs font-black text-[#1a1a1a] uppercase tracking-widest leading-none">Top Activity Zones</h3>
              <p className="text-[10px] text-gray-400 font-bold uppercase mt-1">Cities with most needs</p>
            </div>
          </div>
          <div className="space-y-4">
            {stats.topCities.length > 0 ? stats.topCities.map(([city, count], i) => (
              <div key={city} className="flex items-center justify-between p-4 bg-[#f8f9fd] rounded-[24px] border border-gray-50">
                <div className="flex items-center gap-3">
                  <div className="text-[10px] font-black text-gray-400 w-4">#{i+1}</div>
                  <div className="font-black text-[#1a1a1a] text-sm">{city}</div>
                </div>
                <div className="px-3 py-1 bg-white rounded-full text-[10px] font-black text-[#5e5ce6] shadow-sm border border-gray-100">
                  {count} Missions
                </div>
              </div>
            )) : (
              <div className="text-center py-10 opacity-40">
                <MapPin size={24} className="mx-auto mb-2" />
                <span className="text-[10px] font-black uppercase tracking-widest">No data available</span>
              </div>
            )}
          </div>
          <div className="mt-8 pt-6 border-t border-gray-50">
             <p className="text-[10px] font-medium text-gray-400 italic">"Real-time geographic tracking helps prioritize logistics and regional volunteer recruitment."</p>
          </div>
        </div>
      </div>
    </div>
  );
};

const UserManagement = ({ state, refreshState }: { state: AppState, refreshState: () => void }) => {
  const [search, setSearch] = useState('');
  const filteredUsers = state.users.filter(u => 
    u.name.toLowerCase().includes(search.toLowerCase()) || 
    u.email.toLowerCase().includes(search.toLowerCase())
  );

  const handleRemoveUser = (userId: string) => {
    if (userId === 'admin_1') {
      alert("System Administrators cannot be removed.");
      return;
    }
    if (userId === state.currentUser?.id) {
      alert("You cannot remove your own account from the management portal.");
      return;
    }

    if (confirm(`Are you sure you want to PERMANENTLY remove this member from the Hero platform? This action cannot be undone.`)) {
      storageService.removeUser(userId);
      refreshState();
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <Link to="/admin" className="flex items-center gap-2 text-[#6e6e73] hover:text-[#5e5ce6] font-bold text-xs mb-4 group">
            <ChevronLeft size={16} className="transition-transform group-hover:-translate-x-1" /> Back to Dashboard
          </Link>
          <h1 className="text-3xl font-black text-[#1a1a1a] tracking-tight">Citizen Registry</h1>
          <p className="text-[#6e6e73] font-medium">Manage community access and verified heroes</p>
        </div>
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input 
            className="bg-white border border-gray-200 rounded-2xl py-3.5 pl-12 pr-6 text-sm font-bold focus:outline-none focus:ring-4 focus:ring-indigo-50 min-w-[280px]"
            placeholder="Search members..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="bg-white rounded-[40px] border border-gray-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-gray-50">
                <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest">Member</th>
                <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest">Credentials</th>
                <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest">Join Date</th>
                <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">Access Control</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filteredUsers.map(user => (
                <tr key={user.id} className="hover:bg-gray-50/50 transition-colors group">
                  <td className="px-8 py-6">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-[#f8f9fd] rounded-xl flex items-center justify-center text-[#5e5ce6] font-black shadow-sm overflow-hidden">
                        {user.avatar ? <img src={user.avatar} className="w-full h-full object-cover" /> : user.name[0]}
                      </div>
                      <div>
                        <div className="font-black text-[#1a1a1a] flex items-center gap-2">
                          {user.name}
                          {user.email === 'admin@hero.com' && <ShieldAlert size={14} className="text-indigo-500" />}
                        </div>
                        <div className="text-[10px] text-gray-400 font-medium">{user.id}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <div className="text-sm font-bold text-[#1a1a1a]">{user.email}</div>
                    <div className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">VERIFIED</div>
                  </td>
                  <td className="px-8 py-6">
                    <div className="text-sm font-bold text-[#6e6e73]">
                      {user.joinDate ? new Date(user.joinDate).toLocaleDateString() : 'Historical'}
                    </div>
                  </td>
                  <td className="px-8 py-6 text-right">
                    {user.id !== 'admin_1' && user.id !== state.currentUser?.id && (
                      <button 
                        onClick={() => handleRemoveUser(user.id)}
                        className="px-4 py-2 bg-rose-50 text-rose-500 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-rose-500 hover:text-white transition-all flex items-center gap-2 ml-auto"
                      >
                        <UserX size={14} /> Remove Access
                      </button>
                    )}
                    {(user.id === 'admin_1' || user.id === state.currentUser?.id) && (
                      <span className="px-4 py-2 bg-gray-50 text-gray-400 rounded-xl text-[10px] font-black uppercase tracking-widest cursor-not-allowed">
                        Locked
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const MissionManagement = ({ state, refreshState }: { state: AppState, refreshState: () => void }) => {
  const [search, setSearch] = useState('');
  const filtered = state.requests.filter(r => 
    r.name.toLowerCase().includes(search.toLowerCase()) || 
    r.description.toLowerCase().includes(search.toLowerCase()) ||
    r.category.toLowerCase().includes(search.toLowerCase())
  );

  const handleDelete = (id: string) => {
    if (confirm('Permanently delete this request from database?')) {
      const updated = state.requests.filter(r => r.id !== id);
      storageService.setState({ requests: updated });
      refreshState();
    }
  };

  const handleForceComplete = (id: string) => {
    storageService.updateRequestStatus(id, 'completed');
    refreshState();
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <Link to="/admin" className="flex items-center gap-2 text-[#6e6e73] hover:text-[#5e5ce6] font-bold text-xs mb-4 group">
            <ChevronLeft size={16} className="transition-transform group-hover:-translate-x-1" /> Back to Dashboard
          </Link>
          <h1 className="text-3xl font-black text-[#1a1a1a] tracking-tight">Mission Ledger</h1>
          <p className="text-[#6e6e73] font-medium">System-wide request management</p>
        </div>
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input 
            className="bg-white border border-gray-200 rounded-2xl py-3.5 pl-12 pr-6 text-sm font-bold focus:outline-none focus:ring-4 focus:ring-indigo-50 min-w-[280px]"
            placeholder="Search missions..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="bg-white rounded-[40px] border border-gray-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-gray-50">
                <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest">Requester</th>
                <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest">Category</th>
                <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest">Status</th>
                <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filtered.map(req => (
                <tr key={req.id} className={`hover:bg-gray-50/50 transition-colors group ${req.status === 'expired' ? 'opacity-60 bg-gray-50/20' : ''}`}>
                  <td className="px-8 py-6">
                    <div className="font-black text-[#1a1a1a]">{req.name}</div>
                    <div className="text-[10px] text-gray-400 font-medium truncate max-w-[200px]">{req.description}</div>
                  </td>
                  <td className="px-8 py-6">
                    <span className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest ${req.status === 'expired' ? 'bg-gray-100 text-gray-400' : 'bg-indigo-50 text-[#5e5ce6]'}`}>
                      {req.category}
                    </span>
                  </td>
                  <td className="px-8 py-6">
                    <div className="flex items-center gap-2">
                      <div className={`w-1.5 h-1.5 rounded-full ${
                        req.status === 'live' ? 'bg-rose-500 animate-pulse' :
                        req.status === 'accepted' ? 'bg-amber-500' :
                        req.status === 'expired' ? 'bg-gray-400' :
                        'bg-emerald-500'
                      }`} />
                      <span className={`text-[10px] font-black uppercase tracking-widest ${req.status === 'expired' ? 'text-gray-400' : 'text-[#1a1a1a]'}`}>
                        {req.status}
                      </span>
                    </div>
                  </td>
                  <td className="px-8 py-6 text-right">
                    <div className="flex items-center justify-end gap-2">
                      {req.status !== 'completed' && req.status !== 'expired' && (
                        <button 
                          onClick={() => handleForceComplete(req.id)}
                          className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                          title="Force Complete"
                        >
                          <CheckCircle2 size={18} />
                        </button>
                      )}
                      <button 
                        onClick={() => handleDelete(req.id)}
                        className="p-2 text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                        title="Delete Permanently"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

interface AdminPageProps {
  state: AppState;
  refreshState: () => void;
}

const AdminPage: React.FC<AdminPageProps> = ({ state, refreshState }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const handleLogout = () => {
    storageService.logout();
    refreshState();
    navigate('/login');
  };

  const Sidebar = () => (
    <>
      {isSidebarOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[110] lg:hidden" onClick={() => setIsSidebarOpen(false)} />
      )}
      <div className={`fixed top-0 left-0 bottom-0 w-72 bg-[#0d0c22] text-white flex flex-col z-[120] transition-transform duration-300 ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        <div className="p-10 flex flex-col h-full">
          <div className="flex items-center justify-between mb-12">
            <Link to="/" className="text-2xl font-black flex items-center gap-3">
              <div className="w-10 h-10 bg-[#5e5ce6] rounded-xl flex items-center justify-center text-white text-xl shadow-lg shadow-indigo-500/20">H.</div>
              HERO
            </Link>
            <button className="lg:hidden" onClick={() => setIsSidebarOpen(false)}><X size={20} /></button>
          </div>
          
          <div className="mb-6 px-4">
            <div className="text-[9px] font-black text-gray-500 uppercase tracking-[0.2em] mb-4">Operations</div>
            <nav className="space-y-2">
              <Link to="/admin" onClick={() => setIsSidebarOpen(false)} className={`flex items-center gap-4 px-6 py-4 rounded-2xl font-bold transition-all ${location.pathname === '/admin' ? 'bg-[#5e5ce6] text-white shadow-xl shadow-indigo-500/20' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}>
                <LayoutDashboard size={20} /> Dashboard
              </Link>
              <Link to="/admin/users" onClick={() => setIsSidebarOpen(false)} className={`flex items-center gap-4 px-6 py-4 rounded-2xl font-bold transition-all ${location.pathname === '/admin/users' ? 'bg-[#5e5ce6] text-white shadow-xl shadow-indigo-500/20' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}>
                <Users size={20} /> Citizens
              </Link>
              <Link to="/admin/missions" onClick={() => setIsSidebarOpen(false)} className={`flex items-center gap-4 px-6 py-4 rounded-2xl font-bold transition-all ${location.pathname === '/admin/missions' ? 'bg-[#5e5ce6] text-white shadow-xl shadow-indigo-500/20' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}>
                <ClipboardList size={20} /> Ledger
              </Link>
            </nav>
          </div>

          <div className="mt-auto pt-8 border-t border-white/5">
            <div className="flex items-center gap-4 mb-8 px-4">
              <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center text-white border border-white/10">
                <ShieldCheck size={20} />
              </div>
              <div>
                <div className="text-sm font-black uppercase tracking-tight">Admin System</div>
                <div className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">v4.2.0 SECURE</div>
              </div>
            </div>
            <button 
              onClick={handleLogout}
              className="w-full flex items-center gap-4 px-6 py-4 rounded-2xl font-bold text-rose-400 hover:bg-rose-500/10 transition-all"
            >
              <LogOut size={20} /> Sign Out
            </button>
          </div>
        </div>
      </div>
    </>
  );

  return (
    <div className="min-h-screen bg-[#f8f9fd] flex">
      <Sidebar />
      <div className="flex-1 lg:ml-72 min-h-screen">
        <header className="bg-white/80 backdrop-blur-md sticky top-0 z-[100] px-8 py-6 flex items-center justify-between lg:hidden border-b border-gray-100">
          <button onClick={() => setIsSidebarOpen(true)} className="p-2 -ml-2 text-gray-500">
            <Menu size={24} />
          </button>
          <div className="font-black tracking-tighter text-xl">Hero<span className="text-[#5e5ce6]">.</span>Admin</div>
          <div className="w-10 h-10 bg-indigo-50 rounded-xl" />
        </header>

        <main className="p-6 sm:p-12 max-w-[1400px] mx-auto">
          <Routes>
            <Route index element={<AdminDashboard state={state} />} />
            <Route path="users" element={<UserManagement state={state} refreshState={refreshState} />} />
            <Route path="missions" element={<MissionManagement state={state} refreshState={refreshState} />} />
          </Routes>
        </main>
      </div>
    </div>
  );
};

export default AdminPage;
