
import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import Header from '../components/Header';
import RequestModal from '../components/RequestModal';
import { CATEGORIES } from '../constants';
import { AppState, Category, HelpRequest, Urgency } from '../types';
import { apiService } from '../services/apiService';
import { Search, MapPin, Clock, Trophy, ChevronRight, Zap, Info, AlertTriangle, Navigation, Heart, Star, ShieldCheck, Activity, CheckCircle, Users, Archive, Settings, Loader2 } from 'lucide-react';

interface HomePageProps {
  state: AppState;
  refreshState: () => void;
}

const HomePage: React.FC<HomePageProps> = ({ state, refreshState }) => {
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('ALL');
  const [processingId, setProcessingId] = useState<string | null>(null);

  const userCity = state.currentUser?.city;

  const allLive = state.requests.filter(r => r.status === 'live');

  // Logic: Strictly filter by city if user has one set in their profile.
  // We check if the address field contains the city name (case-insensitive).
  const liveRequests = allLive
    .filter(r => {
      if (!userCity || userCity.toLowerCase() === 'global' || userCity.trim() === '') return true;
      return r.address.toLowerCase().includes(userCity.toLowerCase());
    })
    .filter(r => filterCategory === 'ALL' || r.category === filterCategory)
    .filter(r => 
      r.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      r.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.address.toLowerCase().includes(searchQuery.toLowerCase())
    );

  const userCompleted = state.requests.filter(r => r.status === 'completed' && r.acceptedBy === state.currentUser?.id).length;

  const leaderboard = useMemo(() => {
    const contributors: Record<string, { name: string, count: number }> = {};
    state.requests.forEach(req => {
      if (req.status === 'completed' && req.acceptedBy && req.acceptedByName) {
        if (!contributors[req.acceptedBy]) {
          contributors[req.acceptedBy] = { name: req.acceptedByName, count: 0 };
        }
        contributors[req.acceptedBy].count += 1;
      }
    });

    return Object.entries(contributors)
      .map(([id, data]) => ({
        id,
        name: data.name,
        points: data.count * 10,
        count: data.count,
        avatar: data.name[0]
      }))
      .sort((a, b) => b.points - a.points)
      .slice(0, 5);
  }, [state.requests]);

  const handleAcceptHelp = async (id: string) => {
    if (state.currentUser) {
      setProcessingId(id);
      try {
        await apiService.updateStatus(id, 'accepted', state.currentUser);
        refreshState();
      } catch (e) {
        alert("Server synchronization error. Mission could not be assigned.");
      } finally {
        setProcessingId(null);
      }
    }
  };

  const getUrgencyStyles = (urgency: Urgency) => {
    switch (urgency) {
      case 'EMERGENCY':
        return {
          cardBg: 'bg-rose-50/40 border-rose-100',
          iconBg: 'bg-rose-100 text-rose-500',
          icon: <AlertTriangle className="w-6 h-6" />,
          badge: 'bg-rose-500 text-white',
          badgeText: 'EMERGENCY',
          buttonBg: 'bg-rose-600 hover:bg-rose-700',
          indicator: 'bg-rose-500'
        };
      case 'URGENT':
        return {
          cardBg: 'bg-orange-50/40 border-orange-100',
          iconBg: 'bg-orange-100 text-orange-500',
          icon: <Navigation className="w-6 h-6 rotate-45" />,
          badge: 'bg-orange-500 text-white',
          badgeText: 'URGENT',
          buttonBg: 'bg-orange-600 hover:bg-orange-700',
          indicator: 'bg-orange-500'
        };
      default:
        return {
          cardBg: 'bg-white border-gray-100',
          iconBg: 'bg-indigo-50 text-indigo-500',
          icon: <Heart className="w-6 h-6" />,
          badge: 'bg-indigo-100 text-indigo-600',
          badgeText: 'STANDARD',
          buttonBg: 'bg-indigo-600 hover:bg-indigo-700',
          indicator: 'bg-indigo-500'
        };
    }
  };

  return (
    <div className="min-h-screen pb-24 sm:pb-20 bg-[#f8f9fd]">
      <Header onLogout={refreshState} />

      <main className="max-w-[1280px] mx-auto px-4 sm:px-8 py-8 sm:py-12">
        
        {/* Sync Status */}
        <div className="flex items-center gap-3 mb-8 sm:mb-12 overflow-x-auto hide-scrollbar pb-1">
           <div className="bg-[#5e5ce6] text-white px-5 py-3 rounded-2xl flex items-center gap-3 shrink-0 shadow-lg shadow-indigo-100">
             <Activity className="animate-pulse" size={16} />
             <div className="flex flex-col">
                <span className="text-[8px] font-black uppercase tracking-widest opacity-80 text-white/70">Grid Active</span>
                <span className="text-sm sm:text-lg font-black leading-none">{allLive.length} Global Missions</span>
             </div>
           </div>
           {userCity && userCity !== 'Global' && (
             <div className="bg-emerald-50 text-emerald-600 px-5 py-3 rounded-2xl border border-emerald-100 flex items-center gap-3 shrink-0">
               <MapPin size={16} />
               <div className="flex flex-col">
                  <span className="text-[8px] font-black uppercase tracking-widest text-emerald-500/70">Zone Locked</span>
                  <span className="text-sm sm:text-lg font-black leading-none">{liveRequests.length} in {userCity}</span>
               </div>
             </div>
           )}
        </div>

        {/* Hero Banner Section */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 sm:gap-12 mb-16 sm:mb-20">
          <div className="lg:col-span-8">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-white border border-gray-100 rounded-full text-[10px] sm:text-[12px] font-bold text-[#6e6e73] mb-6 sm:mb-8 shadow-sm">
              <span className="flex w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              Fullstack Node: <span className="text-[#5e5ce6] font-black">{state.currentUser?.name}</span>
              {userCity && <span className="text-gray-300 ml-1">•</span>}
              {userCity && <span className="text-gray-400 font-bold ml-1">{userCity} Operations</span>}
            </div>
            <h1 className="text-[36px] sm:text-[64px] font-[800] text-[#1a1a1a] leading-[1.1] tracking-tight mb-4 sm:mb-2">
              Transforming <br />
              <span className="text-[#5e5ce6]">Kindness into Action.</span>
            </h1>
            
            <p className="text-[#5e5ce6] font-black text-sm sm:text-lg mb-8 tracking-wide uppercase">
              Peer-to-Peer Community Support Network
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
              <div className="bg-white p-6 rounded-[24px] sm:rounded-[32px] border border-gray-50 shadow-sm">
                 <div className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-2">My Missions</div>
                 <div className="text-2xl sm:text-3xl font-black text-[#1a1a1a]">{userCompleted}</div>
                 <div className="w-full bg-gray-50 h-1.5 rounded-full mt-4 overflow-hidden">
                    <div className="bg-emerald-500 h-full rounded-full transition-all duration-500" style={{width: `${Math.min((userCompleted/5)*100, 100)}%`}}></div>
                 </div>
              </div>
            </div>
          </div>
          
          <div className="lg:col-span-4">
            <div className="bg-white rounded-[32px] sm:rounded-[40px] p-6 sm:p-8 shadow-lg border border-gray-100">
              <div className="flex items-center justify-between mb-6 sm:mb-8">
                <div className="flex items-center gap-2 sm:gap-3">
                  <Trophy className="text-amber-400" size={20} />
                  <h3 className="text-[10px] font-black text-[#1a1a1a] uppercase tracking-[0.2em]">Hall of Honor</h3>
                </div>
              </div>
              
              <div className="space-y-3 sm:space-y-4">
                {leaderboard.map((hero, idx) => (
                  <div key={hero.id} className="flex items-center justify-between p-3 sm:p-4 bg-[#f8f9fd] rounded-[20px] border border-gray-100">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-[#5e5ce6] font-black border border-gray-100 shadow-sm uppercase">
                        {hero.avatar || hero.name[0]}
                      </div>
                      <div>
                        <div className="font-black text-[#1a1a1a] text-xs sm:text-sm">{hero.name}</div>
                        <div className="text-[8px] font-black text-indigo-500 uppercase tracking-wider">Rank #{idx + 1}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-black text-[#1a1a1a]">{hero.points}</div>
                      <div className="text-[8px] font-black text-[#a1a1a6] uppercase tracking-wider">EXP</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Quick Action Category Bar - Moved here above Live Missions */}
        <section className="mb-12 sm:mb-16">
          <div className="flex items-center gap-3 mb-8">
            <h3 className="text-xs font-black text-[#1a1a1a] uppercase tracking-[0.2em]">Post New Request</h3>
            <div className="h-[1px] bg-gray-100 flex-1"></div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {CATEGORIES.map(cat => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id as Category)}
                className="group relative h-48 rounded-[32px] overflow-hidden shadow-sm hover:shadow-xl hover:shadow-indigo-100 transition-all active:scale-95"
              >
                <img src={cat.image} className="absolute inset-0 w-full h-full object-cover transition-transform group-hover:scale-110" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                <div className="absolute inset-0 p-6 flex flex-col justify-end items-start text-white">
                  <div className={`${cat.color} p-2.5 rounded-xl mb-3`}>
                    {cat.icon}
                  </div>
                  <span className="text-xs font-black uppercase tracking-widest">{cat.title}</span>
                </div>
              </button>
            ))}
          </div>
        </section>

        {/* Filters & Search - Live Missions Grid */}
        <section className="bg-white rounded-[32px] sm:rounded-[48px] p-6 sm:p-12 shadow-sm border border-gray-100 mb-12 sm:mb-20">
          <div className="flex flex-col gap-8 mb-10">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <h2 className="text-3xl sm:text-4xl font-black text-[#1a1a1a] tracking-tighter">Live Missions</h2>
                  <div className="bg-rose-50 text-rose-500 px-3 py-1 rounded-full border border-rose-100 flex items-center gap-2 animate-pulse">
                    <div className="w-1.5 h-1.5 bg-rose-500 rounded-full"></div>
                    <span className="text-[8px] font-black uppercase tracking-widest">Live Feed</span>
                  </div>
                </div>
                <p className="text-sm sm:text-base text-[#6e6e73] font-medium">
                  {userCity && userCity !== 'Global' ? `Missions currently broadcasting in ${userCity}.` : "Displaying all global community needs."}
                </p>
              </div>
              
              {!userCity && (
                <Link to="/profile" className="px-4 py-2 bg-indigo-50 text-indigo-600 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-indigo-100 transition-all flex items-center gap-2">
                  <Settings size={14} /> Localize My Feed
                </Link>
              )}
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-4">
              <div className="flex items-center gap-2 overflow-x-auto hide-scrollbar w-full sm:w-auto pb-1">
                <button
                  onClick={() => setFilterCategory('ALL')}
                  className={`px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${filterCategory === 'ALL' ? 'bg-[#1a1a1a] text-white' : 'bg-gray-50 text-gray-400 hover:bg-gray-100'}`}
                >
                  All Needs
                </button>
                {CATEGORIES.map(cat => (
                  <button
                    key={cat.id}
                    onClick={() => setFilterCategory(cat.id)}
                    className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${filterCategory === cat.id ? 'bg-[#5e5ce6] text-white' : 'bg-gray-50 text-gray-400 hover:bg-gray-100'}`}
                  >
                    <span className="opacity-50 scale-75">{cat.icon}</span>
                    {cat.title}
                  </button>
                ))}
              </div>
              
              <div className="relative w-full sm:flex-1">
                <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-[#a1a1a6]" size={18} />
                <input 
                  type="text"
                  placeholder="Filter local frequency..."
                  className="bg-[#f8f9fd] border border-gray-100 rounded-2xl py-4 pl-12 pr-4 text-xs font-bold focus:outline-none focus:bg-white w-full transition-all"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
          </div>

          <div className="space-y-4 sm:space-y-6">
            {liveRequests.length === 0 ? (
              <div className="bg-[#f8f9fd] rounded-[32px] p-12 sm:p-24 text-center border border-dashed border-gray-200">
                <Info className="mx-auto mb-4 text-[#a1a1a6]" size={32} />
                <h3 className="text-lg font-black text-[#1a1a1a] mb-2">Region Secure</h3>
                <p className="text-[#6e6e73] text-sm max-w-xs mx-auto">No local missions detected for your current filter parameters.</p>
              </div>
            ) : (
              liveRequests.map(req => {
                const styles = getUrgencyStyles(req.urgency);
                const isProcessing = processingId === req.id;
                return (
                  <div key={req.id} className={`${styles.cardBg} rounded-[28px] sm:rounded-[40px] p-6 sm:p-8 border transition-all flex flex-col xl:flex-row items-center justify-between gap-6 sm:gap-8 group`}>
                    <div className="flex items-center gap-4 sm:gap-8 flex-1 w-full">
                      <div className={`w-14 h-14 sm:w-20 h-20 ${styles.iconBg} rounded-[24px] flex items-center justify-center shrink-0 shadow-sm`}>
                        {styles.icon}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-black text-lg sm:text-2xl text-[#1a1a1a] tracking-tight truncate">{req.name}</h4>
                          <span className={`w-2 h-2 rounded-full ${styles.indicator}`}></span>
                        </div>
                        <div className="flex flex-wrap items-center gap-2 text-[9px] font-black uppercase tracking-wider text-gray-400">
                          <span className="px-2 py-0.5 bg-white rounded-lg border border-gray-100 text-[#5e5ce6]">{req.category}</span>
                          <span>•</span>
                          <span className="flex items-center gap-1"><MapPin size={12} /> {req.address}</span>
                        </div>
                        <p className="mt-4 text-[#6e6e73] italic line-clamp-2 text-sm">"{req.description}"</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-4 w-full xl:w-auto">
                      <div className={`px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest ${styles.badge} whitespace-nowrap`}>
                        {styles.badgeText}
                      </div>
                      <button 
                        disabled={isProcessing}
                        onClick={() => handleAcceptHelp(req.id)}
                        className={`flex-1 ${styles.buttonBg} text-white px-8 py-4 sm:py-5 rounded-[20px] font-black text-[10px] uppercase tracking-widest transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2`}
                      >
                        {isProcessing ? <Loader2 className="animate-spin" size={14} /> : 'Accept Mission'}
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </section>
      </main>

      {selectedCategory && (
        <RequestModal 
          category={selectedCategory} 
          onClose={() => setSelectedCategory(null)}
          onSubmit={refreshState}
        />
      )}
    </div>
  );
};

export default HomePage;
