
import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Camera, ChevronLeft, User, ShieldCheck, Mail, Save, Award, Star, Activity, CheckCircle, Info, MapPin } from 'lucide-react';
import Header from '../components/Header';
import { apiService } from '../services/apiService';
import { AppState } from '../types';

interface ProfilePageProps {
  state: AppState;
  refreshState: () => void;
}

const ProfilePage: React.FC<ProfilePageProps> = ({ state, refreshState }) => {
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const currentUser = state.currentUser;

  const [name, setName] = useState(currentUser?.name || '');
  const [city, setCity] = useState(currentUser?.city || '');
  const [bio, setBio] = useState(currentUser?.bio || '');
  const [avatar, setAvatar] = useState(currentUser?.avatar || '');
  const [isSaving, setIsSaving] = useState(false);

  const userCompleted = state.requests.filter(r => r.status === 'completed' && r.acceptedBy === currentUser?.id).length;
  const impactPoints = userCompleted * 10;

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatar(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    
    try {
      await apiService.updateProfile({
        name,
        city,
        bio,
        avatar
      });
      // Force refresh of the global app state
      refreshState();
      setIsSaving(false);
      alert('Profile updated! Your mission feed will now focus on ' + (city || 'all regions') + '.');
    } catch (error) {
      console.error("Profile update failed", error);
      setIsSaving(false);
      alert("Failed to sync profile changes with the Hero network.");
    }
  };

  if (!currentUser) return null;

  return (
    <div className="min-h-screen bg-[#f8f9fd] pb-24 sm:pb-20">
      <Header onLogout={refreshState} />

      <main className="max-w-[800px] mx-auto px-4 sm:px-8 pt-8 sm:pt-12">
        <div className="flex items-center justify-between mb-10">
          <button 
            onClick={() => navigate(-1)} 
            className="flex items-center gap-2 text-[#6e6e73] hover:text-[#5e5ce6] font-bold text-sm"
          >
            <ChevronLeft size={18} /> Back
          </button>
          <h1 className="text-2xl font-[900] text-[#1a1a1a] tracking-tight">Hero Settings</h1>
          <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-[#5e5ce6] border border-gray-100 shadow-sm">
            <ShieldCheck size={20} />
          </div>
        </div>

        <form onSubmit={handleSave} className="space-y-8 animate-fade-in">
          <div className="bg-white rounded-[40px] p-8 sm:p-12 border border-gray-100 shadow-sm flex flex-col items-center text-center">
            <div className="relative group mb-6">
              <div className="w-32 h-32 sm:w-40 h-40 bg-[#f8f9fd] rounded-full border-4 border-white shadow-xl overflow-hidden flex items-center justify-center">
                {avatar ? (
                  <img src={avatar} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  <User size={48} className="text-gray-300" />
                )}
              </div>
              <button 
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="absolute bottom-1 right-1 sm:bottom-2 sm:right-2 w-10 h-10 sm:w-12 h-12 bg-[#5e5ce6] text-white rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform active:scale-95 border-4 border-white"
              >
                <Camera size={18} />
              </button>
              <input 
                type="file" 
                ref={fileInputRef} 
                className="hidden" 
                accept="image/*" 
                onChange={handleImageUpload}
              />
            </div>
            
            <h2 className="text-2xl font-black text-[#1a1a1a]">{name}</h2>
            <div className="flex items-center gap-2 text-[10px] font-black text-[#5e5ce6] uppercase tracking-widest mt-1">
               <MapPin size={12} /> {city || 'Base of Operations Not Set'}
            </div>

            <div className="grid grid-cols-2 gap-4 w-full mt-10">
              <div className="bg-[#f8f9fd] p-4 rounded-2xl border border-gray-50">
                <div className="text-[8px] font-black text-gray-400 uppercase tracking-widest mb-1">Impact Score</div>
                <div className="text-xl font-black text-[#5e5ce6]">{impactPoints}</div>
              </div>
              <div className="bg-[#f8f9fd] p-4 rounded-2xl border border-gray-50">
                <div className="text-[8px] font-black text-gray-400 uppercase tracking-widest mb-1">Completed</div>
                <div className="text-xl font-black text-[#1a1a1a]">{userCompleted}</div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-[40px] p-8 sm:p-12 border border-gray-100 shadow-sm space-y-8">
            <div className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-[#a1a1a6] uppercase tracking-[0.2em] px-1 flex items-center gap-2">
                    <User size={12} /> Full Display Name
                  </label>
                  <input 
                    required
                    className="w-full bg-[#f8f9fd] border border-gray-100 rounded-2xl py-5 px-6 text-sm font-bold focus:outline-none focus:bg-white focus:ring-4 focus:ring-indigo-50 transition-all"
                    value={name}
                    onChange={e => setName(e.target.value)}
                    placeholder="The name others will see"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-[#a1a1a6] uppercase tracking-[0.2em] px-1 flex items-center gap-2">
                    <MapPin size={12} /> Operation City
                  </label>
                  <input 
                    className="w-full bg-[#f8f9fd] border border-gray-100 rounded-2xl py-5 px-6 text-sm font-bold focus:outline-none focus:bg-white focus:ring-4 focus:ring-indigo-50 transition-all"
                    value={city}
                    onChange={e => setCity(e.target.value)}
                    placeholder="e.g. Sydney, New York..."
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-[#a1a1a6] uppercase tracking-[0.2em] px-1 flex items-center gap-2">
                  <Info size={12} /> Short Bio
                </label>
                <textarea 
                  rows={4}
                  className="w-full bg-[#f8f9fd] border border-gray-100 rounded-2xl py-5 px-6 text-sm font-bold focus:outline-none focus:bg-white focus:ring-4 focus:ring-indigo-50 transition-all resize-none"
                  value={bio}
                  onChange={e => setBio(e.target.value)}
                  placeholder="Share a bit about yourself..."
                />
              </div>
            </div>

            <button 
              type="submit"
              disabled={isSaving}
              className={`w-full py-5 rounded-2xl font-black text-[11px] uppercase tracking-[0.2em] flex items-center justify-center gap-3 transition-all active:scale-[0.98] shadow-xl ${isSaving ? 'bg-gray-100 text-gray-400' : 'bg-[#5e5ce6] text-white shadow-indigo-100 hover:bg-[#4d4bc9]'}`}
            >
              {isSaving ? 'Processing Changes...' : (
                <>
                  <Save size={18} /> Update Profile
                </>
              )}
            </button>
          </div>

          <div className="bg-indigo-50/50 rounded-[32px] p-8 border border-indigo-100/50 flex items-start gap-4">
            <div className="p-3 bg-white rounded-xl text-indigo-500 shadow-sm">
              <MapPin size={20} fill="currentColor" />
            </div>
            <div>
              <h4 className="font-black text-[#1a1a1a] text-sm uppercase tracking-tight">Mission Localization</h4>
              <p className="text-xs text-[#6e6e73] font-medium leading-relaxed mt-1">
                By setting your "Operation City", the Hero app will prioritize missions in your local vicinity. This helps you respond faster to urgent requests near you.
              </p>
            </div>
          </div>
        </form>
      </main>
    </div>
  );
};

export default ProfilePage;
