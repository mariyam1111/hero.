
import React, { useState } from 'react';
import { Mail, Lock, User, ArrowRight, ShieldCheck, Heart, Loader2, Info } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { apiService } from '../services/apiService';

interface LoginPageProps {
  onAuthSuccess: () => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onAuthSuccess }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      // Logic: Hitting the Express /api/auth endpoint
      // Mock allows any password for demo purposes, but checks email for role.
      await apiService.login(email, isLogin ? undefined : name);
      onAuthSuccess();
      navigate('/');
    } catch (error) {
      alert("Authentication failed. Please check your network.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#f8f9fd] p-6">
      <div className="w-full max-w-[440px] hero-card p-10 animate-fade-in border border-gray-100/50 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.05)]">
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-[#5e5ce6] rounded-[24px] text-white font-black text-2xl shadow-xl shadow-indigo-100 mb-6">
            H.
          </div>
          <h1 className="text-3xl font-extrabold text-[#1a1a1a] tracking-tight">
            {isLogin ? 'Welcome Back' : 'Join the Force'}
          </h1>
          <p className="text-[#6e6e73] mt-3 font-medium text-sm">
            {isLogin ? 'Secure access to the Hero Network' : 'Initialize your hero profile across the cloud'}
          </p>
        </div>

        <form onSubmit={handleAuth} className="space-y-5">
          {!isLogin && (
            <div className="relative">
              <User className="absolute left-4 top-1/2 -translate-y-1/2 text-[#a1a1a6]" size={20} />
              <input
                required
                className="w-full glass-input py-4 pl-12 pr-4 text-[#1a1a1a] font-medium placeholder:text-[#a1a1a6] focus:outline-none"
                placeholder="Your Name"
                value={name}
                onChange={e => setName(e.target.value)}
              />
            </div>
          )}
          
          <div className="space-y-1.5">
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-[#a1a1a6]" size={20} />
              <input
                required
                type="email"
                className="w-full glass-input py-4 pl-12 pr-4 text-[#1a1a1a] font-medium placeholder:text-[#a1a1a6] focus:outline-none"
                placeholder="Email Address"
                value={email}
                onChange={e => setEmail(e.target.value)}
              />
            </div>
            {isLogin && (
              <div className="flex items-center gap-1.5 px-1 text-[10px] font-black text-[#5e5ce6] uppercase tracking-widest opacity-80">
                <Info size={10} />
                Admin Example: admin@hero.com
              </div>
            )}
          </div>

          <div className="relative">
            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-[#a1a1a6]" size={20} />
            <input
              required
              type="password"
              className="w-full glass-input py-4 pl-12 pr-4 text-[#1a1a1a] font-medium placeholder:text-[#a1a1a6] focus:outline-none"
              placeholder="Secure Password"
              value={password}
              onChange={e => setPassword(e.target.value)}
            />
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-[#5e5ce6] hover:bg-[#4d4bc9] text-white font-bold py-4 rounded-xl shadow-lg shadow-indigo-100 transition-all transform active:scale-[0.98] flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {isLoading ? (
              <Loader2 className="animate-spin" size={18} />
            ) : (
              <>
                {isLogin ? 'Sign In' : 'Sign Up'}
                <ArrowRight size={18} />
              </>
            )}
          </button>
        </form>

        <div className="mt-8 text-center">
          <button 
            onClick={() => setIsLogin(!isLogin)}
            className="text-[#5e5ce6] font-bold text-sm hover:underline"
          >
            {isLogin ? "New to Hero? Create Cloud Account" : "Already registered? Cloud Login"}
          </button>
        </div>

        <div className="mt-10 pt-8 border-t border-gray-100 flex items-center justify-center">
          <div className="flex items-center gap-2 text-[10px] font-black text-gray-400 uppercase tracking-widest">
             <ShieldCheck size={12} className="text-[#5e5ce6]" /> Persistence: Hero Secure Protocol
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
