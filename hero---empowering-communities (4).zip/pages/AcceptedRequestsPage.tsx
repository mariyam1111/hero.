
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, Clock, MapPin, CheckCircle, Target, Award, List, History, MessageCircle, Navigation } from 'lucide-react';
import Header from '../components/Header';
import ChatOverlay from '../components/ChatOverlay';
import { AppState, HelpRequest } from '../types';
import { storageService } from '../services/storageService';

interface AcceptedRequestsPageProps {
  state: AppState;
  refreshState: () => void;
}

const AcceptedRequestsPage: React.FC<AcceptedRequestsPageProps> = ({ state, refreshState }) => {
  const [activeTab, setActiveTab] = useState<'ACTIVE' | 'HISTORY'>('ACTIVE');
  const [chatRequest, setChatRequest] = useState<HelpRequest | null>(null);
  
  const acceptedRequests = state.requests.filter(r => r.status === 'accepted');
  const historyRequests = state.requests.filter(r => r.status === 'completed');

  const handleComplete = (id: string) => {
    storageService.updateRequestStatus(id, 'completed');
    refreshState();
  };

  const handleTrackLocation = (req: HelpRequest) => {
    const query = req.location ? `${req.location.lat},${req.location.lng}` : encodeURIComponent(req.address);
    window.open(`https://www.google.com/maps/search/?api=1&query=${query}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-[#f8f9fd] pb-24 sm:pb-20">
      <Header onLogout={refreshState} />
      
      <main className="max-w-[1000px] mx-auto px-4 sm:px-8 pt-8 sm:pt-12">
        <div className="flex items-center justify-between mb-8 sm:mb-12">
          <Link to="/" className="flex items-center gap-2 text-[#6e6e73] hover:text-[#5e5ce6] font-bold text-xs sm:text-base">
            <ChevronLeft size={18} /> Back
          </Link>
          <h1 className="text-xl sm:text-3xl font-[900] text-[#1a1a1a]">My Missions</h1>
          <div className="hidden sm:flex items-center gap-2 px-4 py-2 bg-white rounded-xl border border-gray-100 text-[10px] font-black uppercase tracking-widest text-[#5e5ce6]">
            <Award size={14} /> Hero Journal
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 sm:gap-6 mb-10">
          <div className="bg-white p-6 sm:p-8 rounded-2xl sm:rounded-[32px] border border-gray-100 shadow-sm flex flex-col sm:flex-row items-center justify-between">
            <Target className="text-[#5e5ce6] mb-2 sm:mb-0" size={24} />
            <div className="text-center sm:text-right">
              <div className="text-xl sm:text-3xl font-black text-[#1a1a1a]">{acceptedRequests.length}</div>
              <div className="text-[8px] sm:text-[10px] font-black text-[#a1a1a6] uppercase tracking-widest">Active</div>
            </div>
          </div>
          <div className="bg-white p-6 sm:p-8 rounded-2xl sm:rounded-[32px] border border-gray-100 shadow-sm flex flex-col sm:flex-row items-center justify-between">
            <CheckCircle className="text-emerald-500 mb-2 sm:mb-0" size={24} />
            <div className="text-center sm:text-right">
              <div className="text-xl sm:text-3xl font-black text-[#1a1a1a]">{historyRequests.length}</div>
              <div className="text-[8px] sm:text-[10px] font-black text-[#a1a1a6] uppercase tracking-widest">Done</div>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-6 border-b border-gray-200 mb-8 sm:mb-10 overflow-x-auto hide-scrollbar">
          <button 
            onClick={() => setActiveTab('ACTIVE')}
            className={`pb-4 px-2 whitespace-nowrap text-[10px] font-black uppercase tracking-widest relative ${activeTab === 'ACTIVE' ? 'text-[#5e5ce6]' : 'text-[#a1a1a6]'}`}
          >
            Active Missions
            {activeTab === 'ACTIVE' && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#5e5ce6] rounded-full"></div>}
          </button>
          <button 
            onClick={() => setActiveTab('HISTORY')}
            className={`pb-4 px-2 whitespace-nowrap text-[10px] font-black uppercase tracking-widest relative ${activeTab === 'HISTORY' ? 'text-[#5e5ce6]' : 'text-[#a1a1a6]'}`}
          >
            History
            {activeTab === 'HISTORY' && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#5e5ce6] rounded-full"></div>}
          </button>
        </div>

        <div className="space-y-4 sm:space-y-6">
          {(activeTab === 'ACTIVE' ? acceptedRequests : historyRequests).length === 0 ? (
            <div className="bg-white rounded-[24px] sm:rounded-[32px] p-12 sm:p-20 text-center border border-gray-100 shadow-sm">
              <p className="text-gray-400 font-black uppercase tracking-widest text-xs">No entries found</p>
            </div>
          ) : (
            (activeTab === 'ACTIVE' ? acceptedRequests : historyRequests).map(req => (
              <div key={req.id} className={`bg-white rounded-[24px] sm:rounded-[32px] p-5 sm:p-8 border border-gray-100 shadow-sm flex flex-col gap-6 group ${activeTab === 'HISTORY' ? 'opacity-70' : ''}`}>
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 sm:w-14 h-14 ${activeTab === 'HISTORY' ? 'bg-emerald-50 text-emerald-500' : 'bg-[#f8f9fd] text-[#5e5ce6]'} rounded-xl sm:rounded-2xl flex items-center justify-center font-black text-lg`}>
                    {activeTab === 'HISTORY' ? <CheckCircle size={24} /> : req.name[0]}
                  </div>
                  <div>
                    <h3 className="font-black text-base sm:text-xl text-[#1a1a1a]">{req.name}</h3>
                    <span className="text-[9px] font-black uppercase tracking-wider text-[#a1a1a6]">{req.category} Assistance</span>
                  </div>
                </div>

                {activeTab === 'ACTIVE' && (
                  <>
                    <p className="text-[#6e6e73] font-medium leading-relaxed italic text-sm sm:text-base">"{req.description}"</p>
                    <div className="flex flex-col sm:flex-row gap-3">
                      <button 
                        onClick={() => handleTrackLocation(req)}
                        className="flex-1 bg-[#f8f9fd] text-[#1a1a1a] font-black text-[10px] uppercase tracking-widest px-6 py-4 rounded-xl flex items-center justify-center gap-2"
                      >
                        <Navigation size={14} /> Map
                      </button>
                      <button 
                        onClick={() => setChatRequest(req)}
                        className="flex-1 bg-[#f0f4ff] text-[#5e5ce6] font-black text-[10px] uppercase tracking-widest px-6 py-4 rounded-xl flex items-center justify-center gap-2"
                      >
                        <MessageCircle size={14} /> Chat
                      </button>
                      <button 
                        onClick={() => handleComplete(req.id)}
                        className="flex-1 bg-emerald-500 text-white font-black text-[10px] uppercase tracking-widest px-6 py-4 rounded-xl flex items-center justify-center gap-2"
                      >
                        <CheckCircle size={14} /> Complete
                      </button>
                    </div>
                  </>
                )}
              </div>
            ))
          )}
        </div>
      </main>

      {chatRequest && (
        <ChatOverlay 
          request={chatRequest} 
          onClose={() => setChatRequest(null)} 
        />
      )}
    </div>
  );
};

export default AcceptedRequestsPage;
