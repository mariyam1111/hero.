
import React, { useState } from 'react';
import { X, User, Phone, MapPin, Send, Zap, Loader2 } from 'lucide-react';
import { Category, HelpRequest, Urgency } from '../types';
import { apiService } from '../services/apiService';

interface RequestModalProps {
  category: Category;
  onClose: () => void;
  onSubmit: () => void;
}

const RequestModal: React.FC<RequestModalProps> = ({ category, onClose, onSubmit }) => {
  const [urgency, setUrgency] = useState<Urgency>('STANDARD');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [location, setLocation] = useState<{ lat: number; lng: number } | undefined>(undefined);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    address: '',
    description: ''
  });

  const handleGetLocation = () => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        () => alert("Location access denied.")
      );
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    const newRequest: HelpRequest = {
      id: Math.random().toString(36).substr(2, 9),
      ...formData,
      location,
      category,
      urgency,
      status: 'live',
      timestamp: Date.now()
    };
    
    try {
      await apiService.createRequest(newRequest);
      onSubmit();
      onClose();
    } catch (err) {
      alert("Failed to broadcast mission.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-md animate-fade-in">
      <div className="bg-white w-full h-full sm:h-auto sm:max-w-[520px] sm:rounded-[40px] overflow-hidden shadow-2xl flex flex-col scale-in-center">
        <div className="p-8 flex justify-between items-center bg-[#f8f9fd] shrink-0">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-[#5e5ce6] rounded-2xl flex items-center justify-center text-white">
              <Zap size={22} fill="currentColor" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-[#1a1a1a] tracking-tight">{category} Needed</h2>
              <p className="text-[9px] font-black text-[#a1a1a6] uppercase tracking-widest">Post a local mission</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white rounded-xl transition-all border border-transparent hover:border-gray-100">
            <X size={20} />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="flex-1 p-8 pt-0 space-y-6 overflow-y-auto hide-scrollbar pb-12">
          <div className="space-y-3">
            <label className="text-[10px] font-black text-[#a1a1a6] uppercase tracking-widest px-1">Mission Severity</label>
            <div className="flex gap-2 p-1.5 bg-[#f8f9fd] rounded-2xl border border-gray-100">
              {(['STANDARD', 'URGENT', 'EMERGENCY'] as Urgency[]).map((u) => (
                <button
                  key={u}
                  type="button"
                  onClick={() => setUrgency(u)}
                  className={`flex-1 py-3 rounded-xl text-[9px] font-black uppercase tracking-wider transition-all ${
                    urgency === u ? 'bg-[#1a1a1a] text-white shadow-lg' : 'text-[#a1a1a6] hover:text-[#1a1a1a]'
                  }`}
                >
                  {u}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <input
                required
                placeholder="Full Name"
                className="w-full bg-[#f8f9fd] border border-gray-100 rounded-xl py-4 px-5 text-sm font-bold focus:outline-none focus:bg-white"
                value={formData.name}
                onChange={e => setFormData({ ...formData, name: e.target.value })}
              />
              <input
                required
                type="tel"
                placeholder="Phone (555-0123)"
                className="w-full bg-[#f8f9fd] border border-gray-100 rounded-xl py-4 px-5 text-sm font-bold focus:outline-none focus:bg-white"
                value={formData.phone}
                onChange={e => setFormData({ ...formData, phone: e.target.value })}
              />
            </div>
            
            <div className="relative">
              <input
                required
                placeholder="Detailed Street Address (Include City)"
                className="w-full bg-[#f8f9fd] border border-gray-100 rounded-xl py-4 px-5 text-sm font-bold focus:outline-none focus:bg-white pr-12"
                value={formData.address}
                onChange={e => setFormData({ ...formData, address: e.target.value })}
              />
              <button 
                type="button"
                onClick={handleGetLocation}
                className={`absolute right-4 top-1/2 -translate-y-1/2 transition-colors ${location ? 'text-emerald-500' : 'text-[#5e5ce6]'}`}
              >
                <MapPin size={18} />
              </button>
            </div>

            <textarea
              required
              rows={4}
              placeholder="What specifically do you need help with?"
              className="w-full bg-[#f8f9fd] border border-gray-100 rounded-xl py-4 px-5 text-sm font-bold focus:outline-none focus:bg-white resize-none"
              value={formData.description}
              onChange={e => setFormData({ ...formData, description: e.target.value })}
            />
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-[#5e5ce6] text-white font-black text-[11px] uppercase tracking-[0.2em] py-5 rounded-2xl shadow-xl shadow-indigo-100 transition-all active:scale-[0.98] flex items-center justify-center gap-3 disabled:opacity-50"
          >
            {isSubmitting ? <Loader2 className="animate-spin" size={18} /> : <><Send size={18} /> Broadcast Request</>}
          </button>
        </form>
      </div>
    </div>
  );
};

export default RequestModal;
