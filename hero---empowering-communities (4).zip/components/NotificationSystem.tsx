
import React, { useState, useEffect, useCallback } from 'react';
import { Zap, X, MapPin, Bell, ChevronRight } from 'lucide-react';
import { HelpRequest, User } from '../types';

interface NotificationSystemProps {
  currentUser: User | null;
}

interface ToastNotification {
  id: string;
  mission: HelpRequest;
}

const NotificationSystem: React.FC<NotificationSystemProps> = ({ currentUser }) => {
  const [activeToasts, setActiveToasts] = useState<ToastNotification[]>([]);

  const removeToast = (id: string) => {
    setActiveToasts(prev => prev.filter(t => t.id !== id));
  };

  const handleNewMission = useCallback((mission: HelpRequest) => {
    if (!currentUser || !currentUser.city || currentUser.city.toLowerCase() === 'global') return;

    // Check if the mission is in the user's city
    const missionCity = mission.address.toLowerCase();
    const userCity = currentUser.city.toLowerCase();

    if (missionCity.includes(userCity)) {
      const id = Math.random().toString(36).substr(2, 9);
      const newToast = { id, mission };
      
      setActiveToasts(prev => [...prev, newToast]);

      // Play a subtle notification sound (optional, but visual is priority)
      // Automatically remove after 8 seconds
      setTimeout(() => removeToast(id), 8000);
    }
  }, [currentUser]);

  useEffect(() => {
    const handleSocketEvent = (e: any) => {
      const { type, data } = e.detail;
      if (type === 'NEW_MISSION') {
        handleNewMission(data as HelpRequest);
      }
    };

    window.addEventListener('socket_event', handleSocketEvent);
    return () => window.removeEventListener('socket_event', handleSocketEvent);
  }, [handleNewMission]);

  if (activeToasts.length === 0) return null;

  return (
    <div className="fixed top-24 right-4 sm:right-8 z-[200] flex flex-col gap-3 w-full max-w-[360px] pointer-events-none">
      {activeToasts.map(({ id, mission }) => (
        <div 
          key={id}
          className="pointer-events-auto bg-[#1a1a1a] text-white rounded-[24px] p-5 shadow-2xl border border-white/10 animate-fade-in flex flex-col gap-4 relative overflow-hidden group"
        >
          {/* Progress bar for auto-dismiss */}
          <div className="absolute bottom-0 left-0 h-1 bg-[#5e5ce6] animate-[shrink_8s_linear_forwards]" />
          
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-[#5e5ce6] rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
                <Bell size={18} fill="white" />
              </div>
              <div>
                <div className="text-[9px] font-black uppercase tracking-[0.2em] text-[#5e5ce6]">Local Mission Alert</div>
                <div className="text-sm font-black tracking-tight">{mission.name} needs help!</div>
              </div>
            </div>
            <button 
              onClick={() => removeToast(id)}
              className="p-1 hover:bg-white/10 rounded-lg transition-colors text-white/40 hover:text-white"
            >
              <X size={16} />
            </button>
          </div>

          <div className="bg-white/5 rounded-xl p-3 border border-white/5 flex flex-col gap-2">
            <div className="flex items-center gap-2 text-[10px] font-bold text-white/60">
              <MapPin size={12} className="text-[#5e5ce6]" />
              {mission.address}
            </div>
            <p className="text-xs text-white/80 line-clamp-2 leading-relaxed">
              {mission.description}
            </p>
          </div>

          <div className="flex items-center justify-between">
            <div className={`px-3 py-1 rounded-lg text-[8px] font-black uppercase tracking-widest ${
              mission.urgency === 'EMERGENCY' ? 'bg-rose-500' : 
              mission.urgency === 'URGENT' ? 'bg-orange-500' : 'bg-indigo-500'
            }`}>
              {mission.urgency}
            </div>
            <button 
              className="text-[9px] font-black uppercase tracking-[0.15em] flex items-center gap-1 text-[#5e5ce6] group-hover:gap-2 transition-all"
              onClick={() => {
                removeToast(id);
                // In a real app, this would navigate to the mission detail
              }}
            >
              View Mission <ChevronRight size={12} />
            </button>
          </div>
        </div>
      ))}
      <style>{`
        @keyframes shrink {
          from { width: 100%; }
          to { width: 0%; }
        }
      `}</style>
    </div>
  );
};

export default NotificationSystem;
