
import React from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { LogOut, Heart, User, ShieldCheck, ClipboardList, Home, Bell } from 'lucide-react';
import { storageService } from '../services/storageService';

interface HeaderProps {
  onLogout: () => void;
}

const Header: React.FC<HeaderProps> = ({ onLogout }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const state = storageService.getState();
  const isAdmin = state.currentUser?.email === 'admin@hero.com';

  const userCity = state.currentUser?.city;
  const localMissionsCount = state.requests.filter(r => 
    r.status === 'live' && 
    userCity && 
    userCity.toLowerCase() !== 'global' && 
    r.address.toLowerCase().includes(userCity.toLowerCase())
  ).length;

  const handleLogout = () => {
    storageService.logout();
    onLogout();
    navigate('/login');
  };

  return (
    <>
      {/* Top Header */}
      <header className="bg-white/90 backdrop-blur-xl border-b border-gray-100 px-4 sm:px-8 py-4 sm:py-5 flex items-center justify-between sticky top-0 z-[60] shadow-sm">
        <div className="flex items-center gap-2">
          <Link to="/" className="flex items-center gap-2 sm:gap-3 group">
            <div className="bg-[#5e5ce6] p-2 sm:p-2.5 rounded-[14px] sm:rounded-[18px] text-white shadow-lg shadow-indigo-100 group-hover:scale-110 transition-transform duration-300">
              <Heart fill="white" size={20} />
            </div>
            <span className="text-xl sm:text-2xl font-[900] text-[#1a1a1a] tracking-tighter">
              Hero<span className="text-[#5e5ce6]">.</span>
            </span>
          </Link>
        </div>
        
        <div className="flex items-center gap-2 sm:gap-6">
          {/* Notification Bell (Visual Feedback) */}
          <div className="hidden sm:flex items-center justify-center relative w-10 h-10 bg-gray-50 rounded-xl border border-gray-100 text-gray-400">
            <Bell size={18} />
            {localMissionsCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-rose-500 text-white rounded-full flex items-center justify-center text-[9px] font-black border-2 border-white animate-pulse">
                {localMissionsCount}
              </span>
            )}
          </div>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-2 border-r border-gray-100 pr-6 mr-2">
            <Link 
              to="/accepted" 
              className={`flex items-center gap-2.5 px-5 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] transition-all ${location.pathname === '/accepted' ? 'bg-[#f0f4ff] text-[#5e5ce6] shadow-inner' : 'text-[#6e6e73] hover:bg-gray-50 hover:text-[#1a1a1a]'}`}
            >
              <ClipboardList size={16} />
              Mission Log
            </Link>
            {isAdmin && (
              <Link 
                to="/admin" 
                className={`flex items-center gap-2.5 px-5 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] transition-all ${location.pathname.startsWith('/admin') ? 'bg-[#1a1a1a] text-white shadow-xl shadow-gray-200' : 'text-[#6e6e73] hover:bg-gray-50 hover:text-[#1a1a1a]'}`}
              >
                <ShieldCheck size={16} /> Admin Panel
              </Link>
            )}
          </nav>

          <Link 
            to="/profile"
            className="flex items-center gap-3 bg-[#f8f9fd] px-3 sm:px-5 py-1.5 sm:py-2.5 rounded-[14px] sm:rounded-[20px] border border-gray-100 shadow-inner group hover:bg-white transition-all cursor-pointer"
          >
            <div className="w-8 h-8 sm:w-10 h-10 bg-white rounded-lg sm:rounded-xl flex items-center justify-center text-[#5e5ce6] shadow-sm border border-gray-50 group-hover:rotate-6 transition-transform overflow-hidden">
              {state.currentUser?.avatar ? (
                <img src={state.currentUser.avatar} alt="Avatar" className="w-full h-full object-cover" />
              ) : (
                <User size={16} strokeWidth={2.5} />
              )}
            </div>
            <div className="hidden sm:block">
              <div className="text-[9px] font-black text-[#a1a1a6] uppercase leading-none tracking-widest mb-1">
                {isAdmin ? 'System Moderator' : 'Community Contributor'}
              </div>
              <div className="text-[13px] font-[800] text-[#1a1a1a]">
                {state.currentUser?.name || 'Authorized Hero'}
              </div>
            </div>
          </Link>

          <button
            onClick={handleLogout}
            className="p-2 sm:p-3 text-[#a1a1a6] hover:text-rose-500 hover:bg-rose-50 rounded-[14px] sm:rounded-[18px] transition-all border border-transparent hover:border-rose-100 active:scale-90"
            title="Secure Logout"
          >
            <LogOut size={20} />
          </button>
        </div>
      </header>

      {/* Mobile Bottom Navigation */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-xl border-t border-gray-100 px-6 py-3 pb-6 z-[60] flex items-center justify-around shadow-[0_-10px_40px_-15px_rgba(0,0,0,0.1)]">
        <Link 
          to="/" 
          className={`flex flex-col items-center gap-1.5 ${location.pathname === '/' ? 'text-[#5e5ce6]' : 'text-gray-400'}`}
        >
          <div className={`p-2 rounded-xl transition-all ${location.pathname === '/' ? 'bg-indigo-50' : ''}`}>
            <Home size={22} fill={location.pathname === '/' ? '#5e5ce6' : 'none'} />
          </div>
          <span className="text-[9px] font-black uppercase tracking-widest">Feed</span>
        </Link>
        <Link 
          to="/accepted" 
          className={`flex flex-col items-center gap-1.5 ${location.pathname === '/accepted' ? 'text-[#5e5ce6]' : 'text-gray-400'}`}
        >
          <div className={`p-2 rounded-xl transition-all ${location.pathname === '/accepted' ? 'bg-indigo-50' : ''}`}>
            <ClipboardList size={22} fill={location.pathname === '/accepted' ? '#5e5ce6' : 'none'} />
          </div>
          <span className="text-[9px] font-black uppercase tracking-widest">Missions</span>
        </Link>
        <Link 
          to="/profile" 
          className={`flex flex-col items-center gap-1.5 ${location.pathname === '/profile' ? 'text-[#5e5ce6]' : 'text-gray-400'}`}
        >
          <div className={`p-2 rounded-xl transition-all ${location.pathname === '/profile' ? 'bg-indigo-50' : ''}`}>
            <User size={22} fill={location.pathname === '/profile' ? '#5e5ce6' : 'none'} />
          </div>
          <span className="text-[9px] font-black uppercase tracking-widest">Profile</span>
        </Link>
      </nav>
    </>
  );
};

export default Header;
