
import React, { useState, useEffect, useRef } from 'react';
import { X, Send, MessageSquare } from 'lucide-react';
import { HelpRequest, ChatMessage } from '../types';
import { storageService } from '../services/storageService';

interface ChatOverlayProps {
  request: HelpRequest;
  onClose: () => void;
}

const ChatOverlay: React.FC<ChatOverlayProps> = ({ request, onClose }) => {
  const [inputText, setInputText] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);
  const state = storageService.getState();
  const currentUser = state.currentUser;

  const scrollToBottom = (behavior: ScrollBehavior = 'smooth') => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({
        top: scrollRef.current.scrollHeight,
        behavior
      });
    }
  };

  useEffect(() => {
    scrollToBottom('auto');
  }, [request.id]);

  useEffect(() => {
    scrollToBottom();
  }, [request.messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || !currentUser) return;

    const newMessage: ChatMessage = {
      id: Math.random().toString(36).substr(2, 9),
      senderId: currentUser.id,
      senderName: currentUser.name,
      text: inputText.trim(),
      timestamp: Date.now()
    };

    storageService.addMessage(request.id, newMessage);
    setInputText('');
  };

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center sm:p-6 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div 
        className="w-full h-full sm:max-w-[580px] sm:h-[720px] bg-white sm:rounded-[40px] shadow-2xl flex flex-col overflow-hidden scale-in-center"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 sm:px-8 py-5 bg-[#f0f4ff] flex items-center justify-between border-b border-gray-100 shrink-0">
          <div className="flex items-center gap-3 sm:gap-4">
            <div className="w-10 h-10 sm:w-11 h-11 bg-[#5e5ce6] rounded-xl flex items-center justify-center text-white">
              <MessageSquare size={20} fill="white" />
            </div>
            <div className="flex flex-col">
              <h3 className="text-base sm:text-lg font-black text-[#1a1a1a] leading-tight">Support Chat</h3>
              <p className="text-[9px] font-black text-[#5e5ce6] uppercase tracking-widest">{request.category}</p>
            </div>
          </div>
          <button 
            onClick={onClose} 
            className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X size={24} strokeWidth={2.5} />
          </button>
        </div>

        {/* Chat Body */}
        <div 
          ref={scrollRef} 
          className="flex-1 overflow-y-auto p-6 sm:p-8 space-y-4 sm:space-y-6 bg-white hide-scrollbar"
        >
          {request.messages?.map((msg, idx) => {
            const isMe = msg.senderId === currentUser?.id;
            return (
              <div 
                key={msg.id} 
                className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} animate-fade-in`}
              >
                <div className={`px-5 sm:px-6 py-3 sm:py-4 max-w-[85%] rounded-[20px] sm:rounded-[24px] text-sm sm:text-[15px] font-bold shadow-sm ${
                  isMe ? 'bg-[#5e5ce6] text-white rounded-br-sm' : 'bg-gray-100 text-[#1a1a1a] rounded-bl-sm'
                }`}>
                  {msg.text}
                </div>
                <div className="mt-1 text-[8px] sm:text-[10px] font-black text-gray-400 uppercase tracking-widest px-2">
                  {isMe ? 'YOU' : msg.senderName.toUpperCase()} • {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-4 sm:p-8 bg-[#f8f9fd] border-t border-gray-50 pb-8 sm:pb-8">
          <form 
            onSubmit={handleSendMessage} 
            className="flex items-center gap-3 bg-white p-2 rounded-full border border-gray-100 shadow-sm"
          >
            <input 
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Message..."
              className="flex-1 bg-transparent px-5 py-3 text-sm font-bold text-[#1a1a1a] focus:outline-none"
            />
            <button 
              type="submit"
              disabled={!inputText.trim()}
              className="w-10 h-10 sm:w-12 sm:h-12 flex items-center justify-center bg-[#5e5ce6] text-white rounded-full hover:bg-[#4d4bc9] disabled:opacity-50 transition-all active:scale-90"
            >
              <Send size={16} fill="white" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ChatOverlay;
