
import { AppState, HelpRequest, User, ChatMessage } from '../types';
import { MOCK_REQUESTS } from '../constants';

/**
 * API SERVICE (Full-Stack Bridge)
 * This service simulates a real interaction with an Express/MongoDB/Socket.io backend.
 * In a production environment, 'fetch' calls would point to your Node server.
 */

const STORAGE_KEY = 'hero_fullstack_cache';
const MOCK_USERS: User[] = [
  { id: 'admin_1', email: 'admin@hero.com', name: 'System Admin', city: 'Global', joinDate: Date.now() - 1000 * 60 * 60 * 24 * 30 },
  { id: 'hero_1', email: 'sarah@hero.com', name: 'Sarah Miller', city: 'Sydney', bio: 'Community volunteer since 2023.', joinDate: Date.now() - 1000 * 60 * 60 * 24 * 15 }
];

export const apiService = {
  // Simulates GET /api/state
  fetchState: async (): Promise<AppState> => {
    await new Promise(r => setTimeout(r, 400));
    const saved = localStorage.getItem(STORAGE_KEY);
    
    if (!saved) {
      return {
        requests: MOCK_REQUESTS,
        users: MOCK_USERS,
        completedCount: MOCK_REQUESTS.filter(r => r.status === 'completed').length,
        currentUser: null
      };
    }
    return JSON.parse(saved);
  },

  // Simulates POST /api/auth/login
  login: async (email: string, name?: string): Promise<User> => {
    const state = await apiService.fetchState();
    let user = state.users.find(u => u.email === email);
    
    if (!user) {
      user = {
        id: Math.random().toString(36).substr(2, 9),
        email,
        name: name || 'Hero User',
        joinDate: Date.now()
      };
      const updatedUsers = [...state.users, user];
      apiService.persist({ ...state, users: updatedUsers, currentUser: user });
    } else {
      apiService.persist({ ...state, currentUser: user });
    }
    
    return user;
  },

  // Simulates PATCH /api/users/profile
  updateProfile: async (updates: Partial<User>): Promise<void> => {
    const state = await apiService.fetchState();
    if (state.currentUser) {
      const updatedUser = { ...state.currentUser, ...updates };
      const updatedUsers = state.users.map(u => u.id === updatedUser.id ? updatedUser : u);
      
      // Update mission logs if the hero's name changed
      const updatedRequests = state.requests.map(r => {
        if (r.acceptedBy === updatedUser.id) {
          return { ...r, acceptedByName: updatedUser.name };
        }
        return r;
      });

      apiService.persist({ 
        ...state, 
        currentUser: updatedUser, 
        users: updatedUsers,
        requests: updatedRequests
      });
      
      // Notify components about user update
      window.dispatchEvent(new CustomEvent('socket_event', { detail: { type: 'PROFILE_UPDATED', user: updatedUser } }));
    }
  },

  // Simulates POST /api/requests
  createRequest: async (request: HelpRequest): Promise<void> => {
    const state = await apiService.fetchState();
    const updatedRequests = [request, ...state.requests];
    apiService.persist({ ...state, requests: updatedRequests });
    window.dispatchEvent(new CustomEvent('socket_event', { detail: { type: 'NEW_MISSION', data: request } }));
  },

  // Simulates PATCH /api/requests/:id
  updateStatus: async (id: string, status: HelpRequest['status'], user?: User): Promise<void> => {
    const state = await apiService.fetchState();
    const requests = state.requests.map(r => {
      if (r.id === id) {
        const update: any = { status };
        if (status === 'accepted' && user) {
          update.acceptedBy = user.id;
          update.acceptedByName = user.name;
        }
        return { ...r, ...update };
      }
      return r;
    });
    
    const completedCount = requests.filter(r => r.status === 'completed').length;
    apiService.persist({ ...state, requests, completedCount });
    window.dispatchEvent(new CustomEvent('socket_event', { detail: { type: 'MISSION_UPDATED', id, status } }));
  },

  // Simulates POST /api/chat/:requestId
  sendMessage: async (requestId: string, message: ChatMessage): Promise<void> => {
    const state = await apiService.fetchState();
    const requests = state.requests.map(r => {
      if (r.id === requestId) {
        return { ...r, messages: [...(r.messages || []), message] };
      }
      return r;
    });
    apiService.persist({ ...state, requests });
    window.dispatchEvent(new CustomEvent('socket_event', { detail: { type: 'CHAT_MESSAGE', requestId, message } }));
  },

  persist: (state: AppState): void => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    window.dispatchEvent(new Event('storage'));
  },

  logout: () => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const state = JSON.parse(saved);
      apiService.persist({ ...state, currentUser: null });
    }
  }
};
