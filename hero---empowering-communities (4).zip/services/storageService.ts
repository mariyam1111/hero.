
import { AppState, HelpRequest, User, ChatMessage } from '../types';
import { MOCK_REQUESTS } from '../constants';

const STORAGE_KEY = 'hero_fullstack_cache';
const EXPIRATION_TIME = 24 * 60 * 60 * 1000; // 24 Hours

const MOCK_USERS: User[] = [
  { id: 'admin_1', email: 'admin@hero.com', name: 'System Admin', city: 'Global', joinDate: Date.now() - 1000 * 60 * 60 * 24 * 30 },
  { id: 'hero_1', email: 'sarah@hero.com', name: 'Sarah Miller', city: 'Sydney', bio: 'Community volunteer since 2023.', joinDate: Date.now() - 1000 * 60 * 60 * 24 * 15 }
];

const checkExpirations = (requests: HelpRequest[]): HelpRequest[] => {
  const now = Date.now();
  return requests.map(r => {
    if (r.status === 'live' && (now - r.timestamp) > EXPIRATION_TIME) {
      return { ...r, status: 'expired' as const };
    }
    return r;
  });
};

const defaultState: AppState = {
  requests: MOCK_REQUESTS,
  users: MOCK_USERS,
  completedCount: MOCK_REQUESTS.filter(r => r.status === 'completed').length,
  currentUser: null
};

export const storageService = {
  getState: (): AppState => {
    const saved = localStorage.getItem(STORAGE_KEY);
    let state: AppState;
    
    if (!saved) {
      state = defaultState;
    } else {
      try {
        const parsed = JSON.parse(saved);
        state = { ...defaultState, ...parsed };
      } catch (e) {
        state = defaultState;
      }
    }

    const processedRequests = checkExpirations(state.requests);
    const realCompleted = processedRequests.filter(r => r.status === 'completed').length;
    
    return { ...state, requests: processedRequests, completedCount: realCompleted };
  },

  setState: (state: Partial<AppState>): void => {
    const current = storageService.getState();
    const updated = { ...current, ...state };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    window.dispatchEvent(new Event('storage'));
  },

  addUser: (user: User): void => {
    const state = storageService.getState();
    if (!state.users.find(u => u.email === user.email)) {
      storageService.setState({ users: [...state.users, { ...user, joinDate: Date.now() }] });
    }
  },

  removeUser: (userId: string): void => {
    const state = storageService.getState();
    if (userId === 'admin_1' || userId === state.currentUser?.id) return;
    const updatedUsers = state.users.filter(u => u.id !== userId);
    storageService.setState({ users: updatedUsers });
  },

  updateUserProfile: (updates: Partial<User>): void => {
    const state = storageService.getState();
    if (state.currentUser) {
      const updatedUser = { ...state.currentUser, ...updates };
      const updatedUsers = state.users.map(u => u.id === updatedUser.id ? updatedUser : u);
      const updatedRequests = state.requests.map(r => {
        if (r.acceptedBy === updatedUser.id) {
          return { ...r, acceptedByName: updatedUser.name };
        }
        return r;
      });
      storageService.setState({ 
        currentUser: updatedUser, 
        users: updatedUsers, 
        requests: updatedRequests 
      });
    }
  },

  addRequest: (request: HelpRequest): void => {
    const state = storageService.getState();
    storageService.setState({ requests: [request, ...state.requests] });
  },

  updateRequestStatus: (id: string, status: HelpRequest['status'], user?: User): void => {
    const state = storageService.getState();
    const requests = state.requests.map(r => {
      if (r.id === id) {
        const update: Partial<HelpRequest> = { status };
        if (status === 'accepted' && user) {
          update.acceptedBy = user.id;
          update.acceptedByName = user.name;
        }
        return { ...r, ...update };
      }
      return r;
    });
    const realCompleted = requests.filter(r => r.status === 'completed').length;
    storageService.setState({ requests, completedCount: realCompleted });
  },

  addMessage: (requestId: string, message: ChatMessage): void => {
    const state = storageService.getState();
    const requests = state.requests.map(r => {
      if (r.id === requestId) {
        return { ...r, messages: [...(r.messages || []), message] };
      }
      return r;
    });
    storageService.setState({ requests });
  },

  logout: (): void => {
    storageService.setState({ currentUser: null });
  }
};
