
import React, { useState, useEffect, useCallback } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import HomePage from './pages/HomePage';
import AcceptedRequestsPage from './pages/AcceptedRequestsPage';
import AdminPage from './pages/AdminPage';
import ProfilePage from './pages/ProfilePage';
import { apiService } from './services/apiService';
import { AppState } from './types';
import { Loader2 } from 'lucide-react';
import NotificationSystem from './components/NotificationSystem';

const App: React.FC = () => {
  const [state, setState] = useState<AppState | null>(null);
  const [loading, setLoading] = useState(true);

  const loadData = useCallback(async () => {
    const data = await apiService.fetchState();
    setState(data);
    setLoading(false);
  }, []);

  useEffect(() => {
    loadData();
    
    // Simulating Socket.io Listeners
    const handleStorageChange = () => loadData();
    const handleSocketEvent = (e: any) => {
      console.log('Real-time update received:', e.detail);
      loadData();
    };

    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('socket_event', handleSocketEvent);
    
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('socket_event', handleSocketEvent);
    };
  }, [loadData]);

  if (loading || !state) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#f8f9fd]">
        <div className="w-16 h-16 bg-[#5e5ce6] rounded-3xl flex items-center justify-center text-white mb-6 shadow-2xl shadow-indigo-200 animate-bounce">
          <span className="text-2xl font-black">H.</span>
        </div>
        <div className="flex items-center gap-2 text-[10px] font-black text-indigo-500 uppercase tracking-[0.3em]">
          <Loader2 className="animate-spin" size={14} /> Synchronizing with Hero Grid
        </div>
      </div>
    );
  }

  const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    if (!state.currentUser) return <Navigate to="/login" replace />;
    return <>{children}</>;
  };

  const AdminRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    if (!state.currentUser || state.currentUser.email !== 'admin@hero.com') return <Navigate to="/" replace />;
    return <>{children}</>;
  };

  return (
    <HashRouter>
      {/* Global Notification Layer */}
      <NotificationSystem currentUser={state.currentUser} />
      
      <Routes>
        <Route path="/login" element={<LoginPage onAuthSuccess={loadData} />} />
        <Route 
          path="/" 
          element={
            <ProtectedRoute>
              <HomePage state={state} refreshState={loadData} />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/accepted" 
          element={
            <ProtectedRoute>
              <AcceptedRequestsPage state={state} refreshState={loadData} />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/profile" 
          element={
            <ProtectedRoute>
              <ProfilePage state={state} refreshState={loadData} />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/admin/*" 
          element={
            <AdminRoute>
              <AdminPage state={state} refreshState={loadData} />
            </AdminRoute>
          } 
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </HashRouter>
  );
};

export default App;
