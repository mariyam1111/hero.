
export enum Category {
  FOOD = 'Food',
  MEDICINE = 'Medicine',
  SHELTER = 'Shelter',
  EDUCATION = 'Education'
}

export type Urgency = 'STANDARD' | 'URGENT' | 'EMERGENCY';

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: number;
}

export interface HelpRequest {
  id: string;
  name: string;
  phone: string;
  address: string;
  location?: {
    lat: number;
    lng: number;
  };
  description: string;
  category: Category;
  urgency: Urgency;
  status: 'live' | 'accepted' | 'completed' | 'expired';
  timestamp: number;
  messages?: ChatMessage[];
  acceptedBy?: string;
  acceptedByName?: string;
}

export interface User {
  id: string;
  email: string;
  name: string;
  city?: string;
  avatar?: string;
  bio?: string;
  joinDate?: number;
}

export interface AppState {
  requests: HelpRequest[];
  users: User[];
  completedCount: number;
  currentUser: User | null;
}
