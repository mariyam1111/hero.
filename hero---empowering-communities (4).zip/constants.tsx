
import React from 'react';
import { Utensils, Pill, Home, BookOpen } from 'lucide-react';
import { Category, HelpRequest } from './types';

export const CATEGORIES = [
  {
    id: Category.FOOD,
    title: 'Food',
    icon: <Utensils className="w-5 h-5" />,
    color: 'bg-orange-500',
    image: 'https://images.unsplash.com/photo-1547592166-23ac45744acd?auto=format&fit=crop&q=80&w=400'
  },
  {
    id: Category.MEDICINE,
    title: 'Medicine',
    icon: <Pill className="w-5 h-5" />,
    color: 'bg-rose-500',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&q=80&w=400'
  },
  {
    id: Category.SHELTER,
    title: 'Shelter',
    icon: <Home className="w-5 h-5" />,
    color: 'bg-blue-500',
    image: 'https://images.unsplash.com/photo-1518780664697-55e3ad937233?auto=format&fit=crop&q=80&w=400'
  },
  {
    id: Category.EDUCATION,
    title: 'Education',
    icon: <BookOpen className="w-5 h-5" />,
    color: 'bg-indigo-500',
    image: 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&q=80&w=400'
  }
];

const NOW = Date.now();

export const MOCK_REQUESTS: HelpRequest[] = [
  {
    id: 'req_1',
    name: 'Mrs. Gable',
    phone: '555-0102',
    address: '42 Wallaby Way, Sydney',
    description: 'Elderly neighbor needs help carrying groceries up three flights of stairs.',
    category: Category.FOOD,
    urgency: 'STANDARD',
    status: 'live',
    timestamp: NOW - 1000 * 60 * 15 // 15 mins ago
  },
  {
    id: 'req_2',
    name: 'David Chen',
    phone: '555-0199',
    address: 'Greenwood Apartments, Unit 4B',
    description: 'Urgent need for insulin delivery. My car won’t start and the pharmacy closes in 30 minutes.',
    category: Category.MEDICINE,
    urgency: 'EMERGENCY',
    status: 'live',
    timestamp: NOW - 1000 * 60 * 5 // 5 mins ago
  },
  {
    id: 'req_3',
    name: 'St. Mary’s Shelter',
    phone: '555-0444',
    address: '8800 Mission St',
    description: 'We are short on blankets for tonight’s cold snap. Need about 10 heavy blankets.',
    category: Category.SHELTER,
    urgency: 'URGENT',
    status: 'accepted',
    acceptedBy: 'hero_1',
    acceptedByName: 'Sarah Miller',
    timestamp: NOW - 1000 * 60 * 60,
    messages: [
      { id: 'm1', senderId: 'req_3', senderName: 'St. Mary’s Shelter', text: 'Thank you for accepting Sarah! When can you arrive?', timestamp: NOW - 1000 * 60 * 45 },
      { id: 'm2', senderId: 'hero_1', senderName: 'Sarah Miller', text: 'I have 5 blankets in my car, picking up 5 more from the depot now. ETA 20 mins.', timestamp: NOW - 1000 * 60 * 30 }
    ]
  },
  {
    id: 'req_4',
    name: 'Primary School Prep',
    phone: '555-0881',
    address: 'Library Square',
    description: 'Need a tutor for 2nd grade math basics for a group of 3 children.',
    category: Category.EDUCATION,
    urgency: 'STANDARD',
    status: 'completed',
    acceptedBy: 'hero_2',
    acceptedByName: 'Marcus Reed',
    timestamp: NOW - 1000 * 60 * 60 * 24 // Exactly 24 hours ago
  },
  {
    id: 'req_5',
    name: 'The Food Bank',
    phone: '555-0992',
    address: 'Harbor District',
    description: 'Need volunteers to help sort incoming donations for the weekend drive.',
    category: Category.FOOD,
    urgency: 'STANDARD',
    status: 'completed',
    acceptedBy: 'hero_1',
    acceptedByName: 'Sarah Miller',
    timestamp: NOW - 1000 * 60 * 60 * 12
  },
  {
    id: 'req_6',
    name: 'Expired Community Need',
    phone: '555-0223',
    address: '12 Oak St',
    description: 'This mission was posted over 24 hours ago and has expired without a hero.',
    category: Category.EDUCATION,
    urgency: 'STANDARD',
    status: 'live',
    timestamp: NOW - 1000 * 60 * 60 * 26 // 26 hours ago (Will expire)
  }
];
